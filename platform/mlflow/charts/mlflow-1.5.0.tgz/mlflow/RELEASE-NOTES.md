# Changelog

- **Added**: Add existing secret support to auth postgres credentials.
    - [GitHub Issue](https://github.com/community-charts/helm-charts/issues/200)
- **Added**: Add existing secret support to auth admin credentials.
  
- **Added**: Add telemetry flag to enable or disable collecting telemetry data.
  
